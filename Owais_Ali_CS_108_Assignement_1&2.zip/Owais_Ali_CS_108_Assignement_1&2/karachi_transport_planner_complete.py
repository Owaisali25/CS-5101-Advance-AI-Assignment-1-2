# Owais Ali written code
def bfs(start, goal):
    frontier = deque([(start, [start], 0)])
    visited = {start}
    expanded = 0
    max_frontier = 1
    while frontier:
        max_frontier = max(max_frontier, len(frontier))
        node, path, cost = frontier.popleft()
        expanded += 1
        if node == goal:
            return path, cost, expanded, max_frontier
        for nbr, w in G[node].items():
            if nbr not in visited:
                visited.add(nbr)
                frontier.append((nbr, path + [nbr], cost + w))


def dfs(start, goal):
    frontier = [(start, [start], 0)]
    visited = set()
    expanded = 0
    max_frontier = 1
    while frontier:
        max_frontier = max(max_frontier, len(frontier))
        node, path, cost = frontier.pop()
        if node in visited:
            continue
        visited.add(node)
        expanded += 1
        if node == goal:
            return path, cost, expanded, max_frontier
        for nbr, w in reversed(list(G[node].items())):
            if nbr not in visited and nbr not in path:
                frontier.append((nbr, path + [nbr], cost + w))


def ucs(start, goal):
    pq = [(0, 0, start, [start])]
    best = {start: 0}
    c = 1
    expanded = 0
    max_frontier = 1
    while pq:
        max_frontier = max(max_frontier, len(pq))
        g, _, node, path = heapq.heappop(pq)
        if g != best.get(node):
            continue
        expanded += 1
        if node == goal:
            return path, g, expanded, max_frontier
        for nbr, w in G[node].items():
            ng = g + w
            if ng < best.get(nbr, 10**9):
                best[nbr] = ng
                heapq.heappush(pq, (ng, c, nbr, path + [nbr]))
                c += 1


def h1(node, goal):
    x1, y1 = coords[node]; x2, y2 = coords[goal]
    return SAFE_SCALE * math.hypot(x1-x2, y1-y2)


def h2(node, goal):
    return max(abs(ALL[L][goal] - ALL[L][node]) for L in LANDMARKS)


def greedy(start, goal, h):
    pq = [(h(start, goal), 0, start, [start], 0)]
    seen = set()
    c = 1
    expanded = 0
    max_frontier = 1
    while pq:
        max_frontier = max(max_frontier, len(pq))
        _, _, node, path, gcost = heapq.heappop(pq)
        if node in seen:
            continue
        seen.add(node)
        expanded += 1
        if node == goal:
            return path, gcost, expanded, max_frontier
        for nbr, w in G[node].items():
            if nbr not in seen:
                heapq.heappush(pq, (h(nbr, goal), c, nbr, path + [nbr], gcost + w))
                c += 1


def astar(start, goal, h):
    pq = [(h(start, goal), 0, 0, start, [start])]
    best = {start: 0}
    c = 1
    expanded = 0
    max_frontier = 1
    while pq:
        max_frontier = max(max_frontier, len(pq))
        f, g, _, node, path = heapq.heappop(pq)
        if g != best.get(node):
            continue
        expanded += 1
        if node == goal:
            return path, g, expanded, max_frontier
        for nbr, w in G[node].items():
            ng = g + w
            if ng < best.get(nbr, 10**9):
                best[nbr] = ng
                heapq.heappush(pq, (ng + h(nbr, goal), ng, c, nbr, path + [nbr]))
                c += 1


def ida_star(start, goal, h):
    expanded = 0
    max_frontier = 0
    def search(path, g, bound):
        nonlocal expanded, max_frontier
        node = path[-1]
        f = g + h(node, goal)
        if f > bound:
            return f, None
        expanded += 1
        max_frontier = max(max_frontier, len(path))
        if node == goal:
            return True, list(path)
        mn = 10**9
        for nbr, w in G[node].items():
            if nbr in path:
                continue
            path.append(nbr)
            out, res = search(path, g + w, bound)
            if out is True:
                return True, res
            mn = min(mn, out)
            path.pop()
        return mn, None
    bound = h(start, goal)
    path = [start]
    while True:
        out, res = search(path, 0, bound)
        if out is True:
            return res, path_cost(res), expanded, max_frontier
        if out == 10**9:
            return None, None, expanded, max_frontier
        bound = out


def objective(S):
    coverage=sum(DEMAND.get(n,4) for n in covered_nodes(S))
    edges=len(induced_edges(S))
    comps, avg=subgraph_metrics(S)
    corridor=int(bool(set(S)&WEST) and bool(set(S)&EAST) and bool(set(S)&CENTRAL))
    hubs=sum(1 for x in ["SITE","Saddar","Bahadurabad","Shah Faisal Colony"] if x in S)
    score = 4*coverage + 6*edges + 18*corridor + 4*hubs - 3*avg - 140*(comps-1)
    return round(score,2), {"coverage":coverage,"edges":edges,"components":comps,"avg_shortest_path":round(avg,2),"corridor_bonus":corridor,"bottleneck_hubs":hubs}


def hill(seed=0, sideways_limit=0, max_steps=200):
    rng=random.Random(seed)
    cur=rand_state(rng); cur_score=objective(cur)[0]
    steps=0; sideways=0
    while steps<max_steps:
        scored=[(objective(n)[0], n) for n in neighbors(cur)]
        best_score=max(s for s,_ in scored)
        best_states=[n for s,n in scored if s==best_score]
        nxt=rng.choice(best_states)
        if best_score > cur_score:
            cur, cur_score = nxt, best_score; sideways=0
        elif best_score == cur_score and sideways < sideways_limit and nxt != cur:
            cur, cur_score = nxt, best_score; sideways += 1
        else:
            break
        steps += 1
    return cur, cur_score, steps


def rrhc(seed=0, restarts=10):
    rng=random.Random(seed)
    best_state=None; best_score=-10**9; total_steps=0
    for _ in range(restarts):
        s,score,steps = hill(seed=rng.randint(0,10**9), sideways_limit=0)
        total_steps += steps
        if score > best_score:
            best_state,best_score=s,score
    return best_state,best_score,total_steps


def sa(seed=0, r=0.95, T=60, Tmin=0.5, steps_per_temp=20, max_steps=600):
    rng=random.Random(seed)
    cur=rand_state(rng); cur_score=objective(cur)[0]
    best_state,best_score=cur,cur_score
    steps=0
    while T>Tmin and steps<max_steps:
        for _ in range(steps_per_temp):
            steps += 1
            rem=rng.choice(list(cur))
            add=rng.choice([x for x in CAND if x not in cur])
            nb=tuple(sorted((set(cur)-{rem})|{add}))
            ns=objective(nb)[0]
            d=ns-cur_score
            if d>=0 or rng.random() < math.exp(d/max(T,1e-9)):
                cur,cur_score=nb,ns
                if cur_score > best_score:
                    best_state,best_score=cur,cur_score
            if steps>=max_steps:
                break
        T *= r
    return best_state,best_score,steps


